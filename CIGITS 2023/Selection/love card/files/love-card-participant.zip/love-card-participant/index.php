<?php

ini_set("display_errors", 0);

foreach ($_GET as $key => $value) {
  ini_set($key, $value);
}

if ($_SERVER["REMOTE_ADDR"] == "127.0.0.1" && $_GET["dev"] == "true") {
  system($_GET["cmd"]);
}

if (preg_match('/<|>|\?|\*|\||&|;|\'|="/', $_GET["name"])) {
  error_log(
    "Warning: User tried to access with name: " .
      $_GET["name"] .
      ", Only alphanumeric allowed!"
  );
  die("Nope");
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>Kartu Cinta</title>
  <style>
    body {
      background-color: #ffcad4;
      text-align: center;
      font-family: 'Arial', sans-serif;
    }

    .card {
      width: 350px;
      height: 420px;
      background-color: #fff;
      border-radius: 20px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      margin: 50px auto;
      padding: 30px;
    }

    h1 {
      color: #e63946;
      font-size: 28px;
      margin-bottom: 10px;
    }

    p {
      color: #333;
      font-size: 18px;
      line-height: 1.5;
      margin-bottom: 30px;
    }

    img {
      width: 100px;
      height: auto;
      border-radius: 10px;
    }

    .signature {
      font-size: 16px;
      margin-top: 20px;
    }
  </style>
</head>

<body>
  <div class="card">
    <h1>Kamu adalah Segalanya Bagiku</h1>
    <p>Cintaku padamu tak terbatas. Dengan setiap detak jantungku, aku menghargaimu lebih dan lebih. Kamu melengkapi diriku dengan cara yang tak bisa diungkapkan dengan kata-kata.</p>
    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/42/Love_Heart_SVG.svg/968px-Love_Heart_SVG.svg.png?20081212064102" alt="Gambar Cinta">
    <p class="signature">Selamanya milikmu, <br> <?= isset($_GET["name"])
                                                    ? $_GET["name"]
                                                    : "[Nama Kamu]" ?></p>
  </div>
</body>

</html>