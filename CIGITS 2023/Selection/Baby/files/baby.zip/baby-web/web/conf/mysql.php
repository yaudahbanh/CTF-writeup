<?php
	$host = "db";
	$username = "baby-user";
	$password = "baby-pwd";
	$db = "baby-db";

	$mysql = mysqli_connect($host, $username, $password, $db);
?>