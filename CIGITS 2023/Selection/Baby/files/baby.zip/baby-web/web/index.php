<?php
	session_start();
	require("conf/mysql.php");

	if(isset($_SESSION['admin']) && $_SESSION['admin'] == TRUE){
		header("Location: admin.php");
	}
	else{
		if($_SERVER['REQUEST_METHOD'] == "POST"){
			if(isset($_POST['username']) && isset($_POST['password'])){
				$query = "SELECT * FROM users WHERE MD5(username) = MD5('" . $_POST['username'] . "') AND MD5(password) = MD5('" . $_POST['password'] . "')";
				$result = $mysql->query($query);
				if($result && $result->num_rows == 1){
					$row = $result->fetch_array(MYSQLI_ASSOC);
					if($row['admin']){
						$_SESSION['admin'] = TRUE;
						$_SESSION['username'] = $row['username'];
						header("Location: admin.php");
					}
				}
			}

			header("Location: index.php");
		}else{
			include("pages/login.php");
		}
	}
?>