CREATE TABLE `users` (
  `id` int PRIMARY KEY,
  `username` varchar (255),
  `password` varchar (32),
  `admin` tinyint # 0 for regular user, 1 for admin
);
