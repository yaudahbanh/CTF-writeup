<?php
	$data = json_decode(file_get_contents("php://input"), TRUE);

	if(isset($data['message'])){
		die("Thank you for your feedback.");
	}
	die("Welcome to our secret service. By the way, fakeflag{REDACTED}");
?>
