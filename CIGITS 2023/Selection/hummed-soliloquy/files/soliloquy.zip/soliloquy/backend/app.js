const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const jsonpatch = require('fast-json-patch');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

function Payload(){
    this.message = null
}
const payload = new Payload();

// Helper function to reset payload for every request
const cleaner = (req, res, next) => {
    for(let key in payload){
        if (payload.hasOwnProperty(key)) {
            payload[key] = null
        }
    }

    for(let key in payload.constructor.prototype){
        if (payload.constructor.prototype.hasOwnProperty(key)) {
            payload.constructor.prototype[key] = null
        }
    }
    next();
}
app.use(cleaner)

app.post('/submit', (req, res) => {
    let patch = [];

    Object.entries(req.body).forEach(([key, value]) => {
        // No link modification!
        if(key != "link"){
            patch.push({
                "op": "replace",
                "path": "/" + key,
                "value": value
            })
        }
    });
    jsonpatch.applyPatch(payload, patch)
    
    if(!payload.link){
        link = "http://localhost:3001/store";
    }else{
        link = payload.link
    }

    axios.post(link, {
        message: payload.message
    }).then(resp => {
        // console.log(payload, link)
        const response = resp.data
        res.setHeader("Content-Type", "application/json");
        res.json(response);
    }).catch(error => {
        console.error(error);
        const response = {
            "status": "Error storing message."
        }
        res.setHeader("Content-Type", "application/json");
        res.json(response);
    })
});

app.post('/store', (req, res) => {
    // TODO: store the message to our DB, just console it for now tho
    console.log(req, link)
    const response = {
        "status": "Message has been stored."
    }
    res.setHeader("Content-Type", "application/json");
    res.json(response);
})

// Start the server
app.listen(3001, () => {
  console.log('Server is running on port 3001');
});
