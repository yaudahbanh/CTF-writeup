<?php
	header("Content-Type: application/json");

	$url = "http://backend:3001/submit";
	$filtered = [];

	if(!isset($_POST['message']) || $_POST['message'] == ""){
		$message = ["status" => "Please enter your message."];
		die(json_encode($message));
	}


	foreach ($_POST as $key => $value) {
		// don't mention our internal services!
		if(!strstr($key, 'flag') && !strstr($value, 'flag')){
			$filtered[$key] = $value;
		}
	}
	$data = json_encode($filtered);

	$curl = curl_init($url);
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
	curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLINFO_HEADER_OUT, true);
	$response = curl_exec($curl);

	if ($response === false) {
	    $error = curl_error($curl);
	    $message = "cURL Error: " . $error;
	} else {
	    $message = json_decode($response);
	}

	die(json_encode($message));
?>
