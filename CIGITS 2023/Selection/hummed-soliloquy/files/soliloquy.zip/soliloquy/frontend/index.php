<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
	<title>Soliloquy</title>
</head>
<body>
	<div class="container">
		<div class="d-flex flex-wrap justify-content-center" style="height: 100vh;">
			<div id="alert-container" class="col-md-12"></div>
			<form action="POST" class="col-md-6">
				<!-- <input type="hidden" name="url" id="url" value="http://backend:3001/submit"/> -->
				<div class="form-group pb-3">
					<label class="text-small">Say something...</label>
					<textarea name="message" id="message" class="form-control"></textarea>
				</div>
				<a class="btn btn-primary" onclick="submitForm()">Submit</a>
			</form>
		</div>
	</div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
	function submitForm(){
		const message = $('#message').val()

		$.ajax({
			url: "/submit.php",
			method: "POST",
			data: {
				message: message,
			},
			success: function(response){
				$("#alert-container").html("<div class='alert alert-success'>" + response.status + "</div>")
			}
		})
	}
</script>
</html>